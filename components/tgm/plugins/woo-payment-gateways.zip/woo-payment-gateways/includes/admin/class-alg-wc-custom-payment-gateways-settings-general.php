<?php
/**
 * Custom Payment Gateways for WooCommerce - General Section Settings
 *
 * @version 1.1.0
 * @since   1.0.0
 * @author  Algoritmika Ltd.
 */
