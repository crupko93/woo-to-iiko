<?php
/**
 * Plugin Name: Custom Payment gateways for WooCommerce
 * Description: Добавляет 3 произвольных способа оплаты для Woocommerce
 * Requires at least: 4.6
 * Tested up to: 5.0
 * Requires PHP: 5.5+
 * WC requires at least: 3.0.0
 * WC tested up to: 3.5.1
 * Version: 1.0.0
 * Author: Aleksey Tikhomirov
 * Author URI: https://rwsite.ru/
 * Text Domain: woo-gateways
 * Domain Path: /languages
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Check if WooCommerce is active
$plugin = 'woocommerce/woocommerce.php';
if (
	! in_array( $plugin, apply_filters( 'active_plugins', get_option( 'active_plugins', array() ) ) ) &&
	! ( is_multisite() && array_key_exists( $plugin, get_site_option( 'active_sitewide_plugins', array() ) ) )
) {
	return;
}


	// Check if Pro is active, if so then return
	$plugin = 'custom-payment-gateways-for-woocommerce/custom-payment-gateways-for-woocommerce.php';
	


if ( ! class_exists( 'Alg_WC_Custom_Payment_Gateways' ) ) :

/**
 * Main Alg_WC_Custom_Payment_Gateways Class
 *
 * @class   Alg_WC_Custom_Payment_Gateways
 * @version 1.1.0
 * @since   1.0.0
 */
final class Alg_WC_Custom_Payment_Gateways {

	/**
	 * Plugin version.
	 *
	 * @var   string
	 * @since 1.0.0
	 */
	public $version = '1.1.0';

	/**
	 * @var   Alg_WC_Custom_Payment_Gateways The single instance of the class
	 * @since 1.0.0
	 */
	protected static $_instance = null;

	/**
	 * Main Alg_WC_Custom_Payment_Gateways Instance
	 *
	 * Ensures only one instance of Alg_WC_Custom_Payment_Gateways is loaded or can be loaded.
	 *
	 * @version 1.0.0
	 * @since   1.0.0
	 * @static
	 * @return  Alg_WC_Custom_Payment_Gateways - Main instance
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Alg_WC_Custom_Payment_Gateways Constructor.
	 *
	 * @version 1.0.0
	 * @since   1.0.0
	 * @access  public
	 */
	function __construct() {

		// Set up localisation
		load_plugin_textdomain( 'custom-payment-gateways-for-woocommerce', false, dirname( plugin_basename( __FILE__ ) ) . '/langs/' );

		// Include required files
		$this->includes();

		// Settings & Scripts
		if ( is_admin() ) {
			add_filter( 'woocommerce_get_settings_pages', array( $this, 'add_woocommerce_settings_tab' ) );
			add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'action_links' ) );
		}
	}

	/**
	 * Show action links on the plugin screen
	 *
	 * @version 1.1.0
	 * @since   1.0.0
	 * @param   mixed $links
	 * @return  array
	 */
	function action_links( $links ) {
		$custom_links = array();
		return array_merge( $custom_links, $links );
	}

	/**
	 * Include required core files used in admin and on the frontend.
	 *
	 * @version 1.1.0
	 * @since   1.0.0
	 */
	function includes() {
		// Functions
		require_once( 'includes/alg-wc-custom-payment-gateways-functions.php' );
		// Settings
		require_once( 'includes/admin/class-alg-wc-custom-payment-gateways-settings-section.php' );
		$settings = array();
	#	$settings[] = require_once( 'includes/admin/class-alg-wc-custom-payment-gateways-settings-general.php' );
		if ( is_admin() && get_option( 'alg_wc_custom_payment_gateways_version', '' ) !== $this->version ) {
			foreach ( $settings as $section ) {
				foreach ( $section->get_settings() as $value ) {
					if ( isset( $value['default'] ) && isset( $value['id'] ) ) {
						$autoload = isset( $value['autoload'] ) ? ( bool ) $value['autoload'] : true;
						add_option( $value['id'], $value['default'], '', ( $autoload ? 'yes' : 'no' ) );
					}
				}
			}
			update_option( 'alg_wc_custom_payment_gateways_version', $this->version );
		}
		// Core
		 require_once( 'includes/class-alg-wc-custom-payment-gateways-core.php' );
	}

	/**
	 * Add Custom Payment Gateways settings tab to WooCommerce settings.
	 *
	 * @version 1.0.0
	 * @since   1.0.0
	 */
	function add_woocommerce_settings_tab( $settings ) {
		# $settings[] = include( 'includes/admin/class-alg-wc-settings-custom-payment-gateways.php' );
		return $settings;
	}

	/**
	 * Get the plugin url.
	 *
	 * @version 1.0.0
	 * @since   1.0.0
	 * @return  string
	 */
	function plugin_url() {
		return untrailingslashit( plugin_dir_url( __FILE__ ) );
	}

	/**
	 * Get the plugin path.
	 *
	 * @version 1.0.0
	 * @since   1.0.0
	 * @return  string
	 */
	function plugin_path() {
		return untrailingslashit( plugin_dir_path( __FILE__ ) );
	}

}

endif;

if ( ! function_exists( 'alg_wc_custom_payment_gateways' ) ) {
	/**
	 * Returns the main instance of Alg_WC_Custom_Payment_Gateways to prevent the need to use globals.
	 *
	 * @version 1.0.0
	 * @since   1.0.0
	 * @return  Alg_WC_Custom_Payment_Gateways
	 */
	function alg_wc_custom_payment_gateways() {
		return Alg_WC_Custom_Payment_Gateways::instance();
	}
}

alg_wc_custom_payment_gateways();
